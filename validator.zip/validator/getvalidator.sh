wget http://build.fhir.org///validator.zip
unzip validator.zip
rm validator.zip
